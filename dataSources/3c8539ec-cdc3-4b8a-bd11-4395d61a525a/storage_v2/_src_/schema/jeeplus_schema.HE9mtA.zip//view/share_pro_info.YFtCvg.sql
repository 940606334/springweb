CREATE VIEW share_pro_info AS
  SELECT
    `a`.`id`         AS `id`,
    `a`.`product_no` AS `product_no`,
    `a`.`details`    AS `details`,
    `a`.`add_time`   AS `add_time`,
    `b`.`typename`   AS `typename`
  FROM (`jeeplus_schema`.`product_details` `a`
    JOIN `jeeplus_schema`.`product_type` `b` ON ((`a`.`product_type_id` = `b`.`id`)))
  WHERE (`a`.`status` = 1);

