CREATE VIEW view_dormitory AS
  SELECT
    `c`.`id`          AS `id`,
    `c`.`create_date` AS `create_date`,
    `c`.`update_date` AS `update_date`,
    `c`.`parent_id`   AS `parent_id`,
    `c`.`name`        AS `name`,
    `c`.`sort`        AS `sort`,
    `c`.`parent_ids`  AS `parent_ids`,
    `c`.`area_code`   AS `area_code`,
    `a`.`name`        AS `ceng`,
    `b`.`name`        AS `zhuang`
  FROM ((`jeeplus_schema`.`dormitory` `c`
    JOIN `jeeplus_schema`.`dormitory` `a` ON ((`a`.`id` = `c`.`parent_id`))) JOIN `jeeplus_schema`.`dormitory` `b`
      ON ((`a`.`parent_id` = `b`.`id`)));

